package Dominio;

/**
 *
 * @author Bell
 */
public class Cuenta {

    private String IdCuenta;
    private String numCuenta;
    private String fechaApertura;
    private String IdCliente;
    private String Saldo;
    private String Estado;

    public Cuenta(String IdCuenta, String numCuenta, String fechaApertura, String IdCliente, String Saldo, String Estado) {
        this.IdCuenta = IdCuenta;
        this.numCuenta = numCuenta;
        this.fechaApertura = fechaApertura;
        this.IdCliente = IdCliente;
        this.Saldo = Saldo;
        this.Estado = Estado;
    }

    public Cuenta(String numCuenta, String fechaApertura, String IdCliente, String Saldo, String Estado) {
        this.numCuenta = numCuenta;
        this.fechaApertura = fechaApertura;
        this.IdCliente = IdCliente;
        this.Saldo = Saldo;
        this.Estado = Estado;
    }

    public String getIdCuenta() {
        return IdCuenta;
    }

    public void setIdCuenta(String IdCuenta) {
        this.IdCuenta = IdCuenta;
    }

    public String getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }

    public String getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(String fechaApertura) {
        this.fechaApertura = fechaApertura;
    }

    public String getIdCliente() {
        return IdCliente;
    }

    public void setIdCliente(String IdCliente) {
        this.IdCliente = IdCliente;
    }

    public String getSaldo() {
        return Saldo;
    }

    public void setSaldo(String Saldo) {
        this.Saldo = Saldo;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

   
}
