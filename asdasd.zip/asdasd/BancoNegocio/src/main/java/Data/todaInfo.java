package Data;

import Dominio.Cliente;
import Dominio.Domicilio;
import Persistencia.ConexionBD;
import Persistencia.DAO.ClienteDAO;
import Persistencia.DAO.CuentaDAO;
import Persistencia.DAO.IClienteDAO;
import Persistencia.DTO.ClienteNewDTO;
import Persistencia.DTO.CuentaNewDTO;
import Persistencia.DTO.DomicilioNewDTO;
import Persistencia.Excepciones.Excepciones;
import Persistencia.IConexionBD;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class todaInfo {

    Domicilio domicilio;
    Cliente cliente;
    IConexionBD conexionbd;
    CuentaDAO cuentadao;
    private static final Logger LOG = Logger.getLogger(ClienteDAO.class.getName());
    String url = "jdbc:mysql://localhost/Banco";
    String pelos = "root";
    String contra = "21092003";
    IClienteDAO clientedao;
    ConexionBD con = new ConexionBD(url, pelos, contra);
    Connection ConexionBD;

    public todaInfo() throws SQLException {
        this.ConexionBD = con.crearConexion();
        cliente = new Cliente();
        domicilio = new Domicilio();
        conexionbd = new ConexionBD(url, pelos, contra);
        clientedao = new ClienteDAO(conexionbd);

    }

    public void Registro(JTextField nombreTxt, JTextField ApellidoPTxt, JTextField ApellidoMTxt, JTextField UsuarioTxt,
            JTextField contrasenaTxt, JTextField fechaNacimientoTxt, JTextField calleTxt, JTextField coloniaTxt, JTextField numeroTxt) {

        cliente.setNombre(nombreTxt.getText());
        cliente.setApellidoP(ApellidoPTxt.getText());
        cliente.setApellidoM(ApellidoMTxt.getText());
        cliente.setUsuario(UsuarioTxt.getText());
        cliente.setContrasena(contrasenaTxt.getText());

        String fechaTexto = fechaNacimientoTxt.getText();
        DateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date fechaNacimiento = new Date(formatoFecha.parse(fechaTexto).getTime());
            cliente.setFechaNacimiento(fechaNacimiento);
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        domicilio.setCalle(calleTxt.getText());
        domicilio.setColonia(coloniaTxt.getText());
        domicilio.setNum(numeroTxt.getText());

        ClienteNewDTO clienteDTO = new ClienteNewDTO();
        clienteDTO.setNombre(nombreTxt.getText());
        clienteDTO.setApellidoP(ApellidoPTxt.getText());
        clienteDTO.setApellidoM(ApellidoMTxt.getText());
        clienteDTO.setUsuario(UsuarioTxt.getText());
        clienteDTO.setContrasena(contrasenaTxt.getText());
        String fechaTexto2 = fechaNacimientoTxt.getText();
        DateFormat formatoFecha2 = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date fechaNacimiento2 = new Date(formatoFecha2.parse(fechaTexto2).getTime());
            clienteDTO.setFechaNacimiento(fechaNacimiento2);
        } catch (ParseException ex) {
            ex.printStackTrace();
        }

        DomicilioNewDTO domicilioNuevo = new DomicilioNewDTO();
        domicilioNuevo.setCalle(calleTxt.getText());
        domicilioNuevo.setColonia(coloniaTxt.getText());
        domicilioNuevo.setNum(numeroTxt.getText());

        try {

            Cliente clienteAgregado = clientedao.agregarCliente(clienteDTO);
            Domicilio domicilioAgregado = clientedao.agregarDomicilio(domicilioNuevo);

        } catch (Exception e) {

        }

    }

    public void actualizarCliente(int idCliente, String nuevoNombre, String nuevoApellidoP, String nuevoApellidoM,
            String nuevaDireccion, String nuevoUsuario, String nuevaContrasena, Date nuevaFechaNacimiento,
            String nuevoNum, String nuevaColonia, String nuevaCalle) {
        String sql = "UPDATE Cliente SET nombre = ?, ApellidoP = ?, ApellidoM = ?, FechaNacimiento = ?, usuario = ?, "
                + "contrasena = ? WHERE idCliente = ?";

        try (Connection conn = ConexionBD.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nuevoNombre);
            stmt.setString(2, nuevoApellidoP);
            stmt.setString(3, nuevoApellidoM);
            stmt.setDate(4, nuevaFechaNacimiento);
            stmt.setString(5, nuevoUsuario);
            stmt.setString(6, nuevaContrasena);
            stmt.setInt(7, idCliente);

            int filasActualizadas = stmt.executeUpdate();
            if (filasActualizadas > 0) {
                System.out.println("Cliente actualizado correctamente.");
            } else {
                System.out.println("No se pudo actualizar el cliente.");
            }
        } catch (SQLException e) {
            System.err.println("Error al intentar actualizar el cliente: " + e.getMessage());
        }

        sql = "UPDATE Domicilio SET num = ?, colonia = ?, calle = ? WHERE idCliente = ?";
        try (Connection conn = ConexionBD.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nuevoNum);
            stmt.setString(2, nuevaColonia);
            stmt.setString(3, nuevaCalle);
            stmt.setInt(4, idCliente);

            int filasActualizadas = stmt.executeUpdate();
            if (filasActualizadas > 0) {
                System.out.println("Dirección actualizada correctamente.");
            } else {
                System.out.println("No se pudo actualizar la dirección.");
            }
        } catch (SQLException e) {
            System.err.println("Error al intentar actualizar la dirección: " + e.getMessage());
        }
    }
    
    public int obtenerIdClientePorUsuario(String usuario) throws SQLException {
    int idCliente = -1; 
    String sql = "SELECT idCliente FROM Cliente WHERE usuario = ?";
    
    try (Connection conn = ConexionBD.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, usuario);
        
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                idCliente = rs.getInt("idCliente");
            }
        }
    } catch (SQLException e) {
        System.err.println("Error al intentar obtener el idCliente: " + e.getMessage());
        throw e; 
    }
    
    return idCliente;
}

    public String Cosonuevo() throws Excepciones {

        return null;

    }

    public String Cosonuevo2() throws Excepciones {

        return null;

    }

    public String Cosonuevo3() throws Excepciones {

        return null;

    }

    public void agregar() throws Excepciones {
        CuentaNewDTO dtos = new CuentaNewDTO();
        cuentadao.CuentaNueva(dtos);

    }

}
