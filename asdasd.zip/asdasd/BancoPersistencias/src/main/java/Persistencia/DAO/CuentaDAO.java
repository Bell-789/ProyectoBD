/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia.DAO;

import Dominio.Cuenta;
import Persistencia.DTO.CuentaNewDTO;
import Persistencia.Excepciones.Excepciones;
import Persistencia.IConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CuentaDAO  {

    IConexionBD conexionBD;
    private static final Logger LOG = Logger.getLogger(ClienteDAO.class.getName());

    public CuentaDAO(IConexionBD conexionBD) {
        this.conexionBD = conexionBD;
    }

    public Cuenta CuentaNueva(CuentaNewDTO cuenta) throws Excepciones {

        int random = 0;
        random = (int) (Math.random() * (900000) + 100000);

        String sentenciaSQL = "Insert into Cuente (numCuenta, FechaInicio) "
                + "Values ('" + random + " ',curdate())";

        try {
            Connection conexion = this.conexionBD.crearConexion();
            PreparedStatement comandoSQL = conexion.prepareStatement(sentenciaSQL, Statement.RETURN_GENERATED_KEYS);

            int registrosModificados = comandoSQL.executeUpdate();
            LOG.log(Level.INFO, "Se agregaron con éxito {0} ", registrosModificados);
            ResultSet registroGenerado = comandoSQL.getGeneratedKeys();
            registroGenerado.next();

            Cuenta cuentaNueva = new Cuenta(cuenta.getNumCuenta(), cuenta.getFechaApertura(),
                    cuenta.getIdCliente(), cuenta.getEstado(), cuenta.getSaldo());
            return cuentaNueva;
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "No se agregó con éxito ", e);
            throw new Excepciones("No se pudo guardar e ", e);
        }

    }
}
