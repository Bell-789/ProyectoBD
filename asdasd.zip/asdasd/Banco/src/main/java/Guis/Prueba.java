
package Guis;

/**
 *
 * @author Bell
 */
public class Prueba {

   
    public static void main(String[] args) {
      
        Inicio in = new Inicio();
        in.setVisible(true);
    }
    
}
